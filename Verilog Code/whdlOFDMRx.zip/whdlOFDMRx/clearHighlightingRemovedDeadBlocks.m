SLStudio.Utils.RemoveHighlighting(get_param('whdlOFDMRx','Handle'));
