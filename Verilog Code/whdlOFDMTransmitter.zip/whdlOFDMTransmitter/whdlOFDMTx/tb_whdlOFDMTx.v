`timescale 1ns / 1ps

module tb_whdlOFDMTx;

    // Inputs
    reg clk;
    reg reset;
    reg enb;
    reg [1:0] modTypeIndex;
    reg [1:0] codeRateIndex;
    reg data;
    reg valid;

    // Outputs
    wire signed [15:0] txData_re;
    wire signed [15:0] txData_im;
    wire txValid;
    wire ready;

    // Instantiate the DUT
    whdlOFDMTx_whdlOFDMTx uut (
        .clk(clk),
        .reset(reset),
        .enb(enb),
        .modTypeIndex(modTypeIndex),
        .codeRateIndex(codeRateIndex),
        .data(data),
        .valid(valid),
        .txData_re(txData_re),
        .txData_im(txData_im),
        .txValid(txValid),
        .ready(ready)
    );

    // Clock generation (10ns period => 100MHz)
    always #5 clk = ~clk;

    initial begin
        // Initialize signals
        clk = 0;
        reset = 1;
        enb = 0;
        modTypeIndex = 0;
        codeRateIndex = 0;
        data = 0;
        valid = 0;

        // Apply reset
        #20 reset = 0;
        enb = 1;

        // Test Case 1: QPSK (modTypeIndex=0), codeRateIndex=0
        modTypeIndex = 2'b00;
        codeRateIndex = 2'b00;

        send_data_sequence(16);

        // Test Case 2: 16-QAM (modTypeIndex=1), codeRateIndex=1
        #100;
        modTypeIndex = 2'b01;
        codeRateIndex = 2'b01;

        send_data_sequence(16);

        // Test Case 3: 64-QAM (modTypeIndex=2), codeRateIndex=2
        #100;
        modTypeIndex = 2'b10;
        codeRateIndex = 2'b10;

        send_data_sequence(16);

        // End Simulation
        #500 $finish;
    end

    // Task to send a sequence of data bits
    task send_data_sequence(input integer num_bits);
        integer i;
        begin
            for (i = 0; i < num_bits; i = i + 1) begin
                @(posedge clk);
                data = $random % 2; // Random bit (0 or 1)
                valid = 1;
            end
            @(posedge clk);
            valid = 0; // Stop sending
        end
    endtask

    // Monitor outputs
    initial begin
        $monitor("Time=%0t | txValid=%b txData_re=%d txData_im=%d ready=%b",
                 $time, txValid, txData_re, txData_im, ready);
    end

endmodule
