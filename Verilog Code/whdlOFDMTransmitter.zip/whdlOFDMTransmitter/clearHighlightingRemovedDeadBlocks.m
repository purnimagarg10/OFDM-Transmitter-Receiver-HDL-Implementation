SLStudio.Utils.RemoveHighlighting(get_param('whdlOFDMTx','Handle'));
